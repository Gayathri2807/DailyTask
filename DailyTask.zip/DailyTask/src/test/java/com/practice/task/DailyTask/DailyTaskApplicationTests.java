package com.practice.task.DailyTask;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DailyTaskApplicationTests {

	@Test
	void contextLoads() {
	}

}
