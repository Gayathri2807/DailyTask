package com.practice.task.DailyTask.Service;

import com.practice.task.DailyTask.Model.InputInventory;
import com.practice.task.DailyTask.Model.Product;

import java.util.List;

public interface ProductList {
    public List<Product> getproductList();

    public String getDate(String date);

}
