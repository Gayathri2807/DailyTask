package com.practice.task.DailyTask;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DailyTaskApplication {

	public static void main(String[] args) {

		SpringApplication.run(DailyTaskApplication.class, args);
	}

}
