package com.practice.task.DailyTask.Controller;

import com.practice.task.DailyTask.Model.Product;
import com.practice.task.DailyTask.Service.ProductList;
import com.practice.task.DailyTask.Service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
@RestController
public class ProductController {

    @Autowired
    private ProductList productList;


    @GetMapping("/products")
    public List<Product> productList(){
        List<Product> productOutput = productList.getproductList();
        return productOutput;
    }

    @PostMapping("/getInventory/{date}")
    public String avlDate(@PathVariable String date){
        return productList.getDate(date);
    }
}
