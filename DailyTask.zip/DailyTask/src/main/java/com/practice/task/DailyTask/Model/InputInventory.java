package com.practice.task.DailyTask.Model;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class InputInventory {
    private String productId;
    private String prodName;
    private String reqDate;

}
